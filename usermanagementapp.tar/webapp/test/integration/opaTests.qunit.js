/* global QUnit */

sap.ui.require([
	"usermanagementapp/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});