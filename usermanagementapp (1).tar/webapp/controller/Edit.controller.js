sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/m/library",
    "sap/ui/Device",
    "sap/m/MessageBox",
    "sap/ui/core/Core"
], function (BaseController, JSONModel, formatter, mobileLibrary, Device, MessageBox, Core) {
    "use strict";

    // shortcut for sap.m.URLHelper
    var URLHelper = mobileLibrary.URLHelper;

    return BaseController.extend("usermanagementapp.controller.Edit", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        onInit: function () {
            // Model used to manipulate control states. The chosen values make sure,
            // detail page is busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            var oViewModel = new JSONModel({
                busy: false,
                delay: 0,
                lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading"),
                groups: [],
                checkBoxSelected: false,
                NTitle: "N-1",
                NInput: "",
                PATitle: "Product Area",
                PAInput: "",
                LETitle: "Legal Entity",
                LEInput: ""
            });

            this.getRouter().getRoute("edit").attachPatternMatched(this._onObjectMatched, this);

            this.setModel(oViewModel, "detailView");

            this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
            this._fnGetDistinctGroups();

            var oView = this.getView(),
                oMM = Core.getMessageManager();
            // attach handlers for validation errors
            oMM.registerObject(oView.byId("idIpN"), true);
            oMM.registerObject(oView.byId("idIpLE"), true);
            oMM.registerObject(oView.byId("idIpPA"), true);
        },
        _validateInput: function (oInput) {
            var sValueState = "None";
            var bValidationError = false;
            var oBinding = oInput.getBinding("value");

            try {
                oBinding.getType().validateValue(oInput.getValue());
            } catch (oException) {
                sValueState = "Error";
                bValidationError = true;
            }

            oInput.setValueState(sValueState);

            return bValidationError;
        },

        onChange: function (oEvent) {
            var oInput = oEvent.getSource();
            this._validateInput(oInput);
        },
        _fnGetDistinctGroups: function () {
            this.getOwnerComponent().getModel().read("/UserMasterData", {
                urlParameters: {
                    "$expand": "linkToUserGroup($select=USER_GROUP)",
                    "$select": "USER_ID", // reduce data load
                },
                //  filters: aFilter,
                success: function (oData) {
                    debugger

                    var obj = { "USER_GROUP": "" },
                        aAllGroups = [];
                    oData.results.forEach(function (item) {

                        item.linkToUserGroup.results.forEach(function (oCurrentEle) {
                            if (aAllGroups.indexOf(oCurrentEle["USER_GROUP"]) == -1) {
                                obj = { "USER_GROUP": oCurrentEle.USER_GROUP };
                                aAllGroups.push(obj);

                            }
                        });

                    });

                    var uniqueGroups = [];
                    var aUniqueArr = aAllGroups.filter(element => {
                        var isDuplicate = uniqueGroups.includes(element.USER_GROUP);
                        if (!isDuplicate) {
                            uniqueGroups.push(element.USER_GROUP);
                            return true;
                        }
                        return false;
                    });
                    var oViewModel = this.getModel("detailView");

                    oViewModel.setProperty("/groups", aUniqueArr);
                    debugger
                }.bind(this),
                error: function (err) {
                    debugger
                }
            });


        },
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Event handler when the share by E-Mail button has been clicked
         * @public
         */
        onSendEmailPress: function () {
            var oViewModel = this.getModel("detailView");

            URLHelper.triggerEmail(
                null,
                oViewModel.getProperty("/shareSendEmailSubject"),
                oViewModel.getProperty("/shareSendEmailMessage")
            );
        },


        /**
         * Updates the item count within the line item table's header
         * @param {object} oEvent an event containing the total number of items in the list
         * @private
         */
        onListUpdateFinished: function (oEvent) {
            var sTitle,
                iTotalItems = oEvent.getParameter("total"),
                oViewModel = this.getModel("detailView");

            // only update the counter if the length is final
            if (this.byId("editLineItemsList").getBinding("items").isLengthFinal()) {
                if (iTotalItems) {
                    sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
                } else {
                    //Display 'Line Items' instead of 'Line items (0)'
                    sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
                }
                oViewModel.setProperty("/lineItemListTitle", sTitle);

            }
        },
        onListUpdateFinished_N: function (oEvent) {
            var sTitle,
                iTotalItems = oEvent.getParameter("total"),
                oViewModel = this.getModel("detailView");

            // only update the counter if the length is final
            if (this.byId("idNTable").getBinding("items").isLengthFinal()) {
                if (iTotalItems) {
                    // sTitle =  "N-1 (" + iTotalItems + ")"
                    sTitle = "N-1";
                } else {
                    //Display 'Line Items' instead of 'Line items (0)'
                    sTitle = "N-1";
                }
                oViewModel.setProperty("/NTitle", sTitle);

            }
        },
        onListUpdateFinished_LE: function (oEvent) {
            var sTitle,
                iTotalItems = oEvent.getParameter("total"),
                oViewModel = this.getModel("detailView");

            // only update the counter if the length is final
            if (this.byId("idLETable").getBinding("items").isLengthFinal()) {
                if (iTotalItems) {
                    // sTitle =  "Legal Entity (" + iTotalItems + ")"
                    sTitle = "Legal Entity";
                } else {
                    //Display 'Line Items' instead of 'Line items (0)'
                    sTitle = "Legal Entity";
                }
                oViewModel.setProperty("/LETitle", sTitle);

            }
        },
        onListUpdateFinished_PA: function (oEvent) {
            var sTitle,
                iTotalItems = oEvent.getParameter("total"),
                oViewModel = this.getModel("detailView");

            // only update the counter if the length is final
            if (this.byId("idPATable").getBinding("items").isLengthFinal()) {
                if (iTotalItems) {
                    // sTitle =  "Product Area (" + iTotalItems + ")"
                    sTitle = "Product Area";
                } else {
                    //Display 'Line Items' instead of 'Line items (0)'
                    sTitle = "Product Area";
                }
                oViewModel.setProperty("/PATitle", sTitle);

            }
        },

        /* =========================================================== */
        /* begin: internal methods                                     */
        /* =========================================================== */

        /**
         * Binds the view to the object path and expands the aggregated line items.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        _onObjectMatched: function (oEvent) {
            debugger
            var sObjectId = oEvent.getParameter("arguments").objectId;
            this._sObjectId = sObjectId;
            this.getModel("appView").setProperty("/layout", "EndColumnFullScreen");
            this.getModel().metadataLoaded().then(function () {
                var sObjectPath = this.getModel().createKey("UserMasterData", {
                    USER_ID: sObjectId
                });
                this._bindView("/" + sObjectPath);
            }.bind(this));
            // this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
            // this.getModel().metadataLoaded().then( function() {
            //     var sObjectPath = this.getModel().createKey("UserMasterData", {
            //         USER_ID:  sObjectId
            //     });
            //     this._bindView("/" + sObjectPath);
            // }.bind(this));
        },

        /**
         * Binds the view to the object path. Makes sure that detail view displays
         * a busy indicator while data for the corresponding element binding is loaded.
         * @function
         * @param {string} sObjectPath path to the object to be bound to the view.
         * @private
         */
        _bindView: function (sObjectPath) {
            // Set busy indicator during view binding
            var oViewModel = this.getModel("detailView");

            // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
            oViewModel.setProperty("/busy", false);

            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oViewModel.setProperty("/busy", true);
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("detailObjectNotFound");
                // if object could not be found, the selection in the list
                // does not make sense anymore.
                this.getOwnerComponent().oListSelector.clearListListSelection();
                return;
            }

            var sPath = oElementBinding.getPath(),
                oResourceBundle = this.getResourceBundle(),
                oObject = oView.getModel().getObject(sPath),
                sObjectId = oObject.USER_ID,
                sObjectName = oObject.USER_ID,
                oViewModel = this.getModel("detailView");
            this._sPath = sPath;
            this._oObject = oObject;
            this.getOwnerComponent().oListSelector.selectAListItem(sPath);

            oViewModel.setProperty("/shareSendEmailSubject",
                oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
            oViewModel.setProperty("/shareSendEmailMessage",
                oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
        },

        _onMetadataLoaded: function () {
            // Store original busy indicator delay for the detail view
            var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
                oViewModel = this.getModel("detailView"),
                oLineItemTable = this.byId("lineItemsList"),
                iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

            // Make sure busy indicator is displayed immediately when
            // detail view is displayed for the first time
            oViewModel.setProperty("/delay", 0);
            oViewModel.setProperty("/lineItemTableDelay", 0);

            oLineItemTable.attachEventOnce("updateFinished", function () {
                // Restore original busy indicator delay for line item table
                oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
            });

            // Binding the view will set it to not busy - so the view is always busy if it is not bound
            oViewModel.setProperty("/busy", true);
            // Restore original busy indicator delay for the detail view
            oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
        },

        /**
         * Set the full screen mode to false and navigate to list page
         */
        onCloseDetailPress: function () {
            this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
            // No item should be selected on list after detail page is closed
            this.getOwnerComponent().oListSelector.clearListListSelection();
            this.getRouter().navTo("list");
        },

        /**
         * Toggle between full and non full screen mode.
         */
        toggleFullScreen: function () {
            var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
            this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
            if (!bFullScreen) {
                // store current layout and go full screen
                this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
                this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
            } else {
                // reset to previous layout
                this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
            }
        },
        onDeleteCheckBoxSelected: function (oEvt) {
            var selectedRow = oEvt.getSource().getParent();
            var oCheckBoxReference = $(selectedRow.$().find('.sapMCb'))[0];
            var oCheckBox = sap.ui.getCore().byId(oCheckBoxReference.getAttribute("id"));
            oCheckBox.getProperty("selected");
            //var oContext= oEvt.getSource().getParent().getBoundContext();
        },
        navBackToDetailsScreen: function () {
            var bReplace = !Device.system.phone;
            // set the layout property of FCL control to show two columns
            this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
            this.getRouter().navTo("object", {
                objectId: this._sObjectId
            }, bReplace);
        },

        onSave: function () {
            var oViewModel = this.getModel("detailView"),
                // collect input controls
                oView = this.getView(),
                aInputs = [
                    oView.byId("idIpN"),
                    oView.byId("idIpLE"),
                    oView.byId("idIpPA")
                ],
                bValidationError = false;

            // Check that inputs are not empty.
            // Validation does not happen during data binding as this is only triggered by user actions.
            aInputs.forEach(function (oInput) {
                bValidationError = this._validateInput(oInput) || bValidationError;
            }, this);

            if (bValidationError) {
                MessageBox.alert("A validation error has occurred. Complete your input first.");

            } else {
                
            }
        },
        fnUpdateTeamsTable: function () {
            var oViewModel = this.getModel("detailView");
            var oGroupsMultiComboBox = this.byId("idGroupsMultiComboBox");
            var aGroupsMultiComboBoxSelectedKeys = oGroupsMultiComboBox.getSelectedKeys();
            var oCheckBoxReference = {};
            var oCheckBox = {};
            var isSelected = false;
            var oGroupObject = {
                "USER_ID": " ",
                "USER_GROUP": " ",
                "USER_NAME": " "
            }
            var aGroup = [];
            var oObject = this.getView().getModel().getObject(this._sPath);
            var oTeamsTable = this.byId("editLineItemsList");
            var oItems = oTeamsTable.getItems();
            oItems.forEach(function (item) {
                oCheckBoxReference = $(item.$().find('.sapMCb'))[0];
                oCheckBox = sap.ui.getCore().byId(oCheckBoxReference.getAttribute("id"));
                isSelected = oCheckBox.getProperty("selected");
                if (!isSelected) {
                    oGroupObject = {
                        "USER_ID": item.getBindingContext().getObject().USER_ID,
                        "USER_GROUP": item.getBindingContext().getObject().USER_GROUP,
                        "USER_NAME": item.getBindingContext().getObject().USER_NAME
                    }
                    aGroup.push(oGroupObject);
                }

            })
            oGroupObject = {};
            if (aGroupsMultiComboBoxSelectedKeys.length > 0) {
                aGroupsMultiComboBoxSelectedKeys.forEach(function (key) {
                    oGroupObject = {
                        "USER_ID": oObject.USER_ID,
                        "USER_GROUP": key,
                        "USER_NAME": oObject.USER_NAME
                    }
                    const index = aGroup.findIndex(object => object.USER_GROUP === key);
                    if (index === -1) {
                        aGroup.push(oGroupObject);
                    }

                });
            }
            var oPayload =
            {
                "USER_ID": oObject.USER_ID,
                "USER_NAME": oObject.USER_NAME,
                "EMAIL": oObject.EMAIL,
                "linkToUserGroup": aGroup


            };

            var oModel = this.getOwnerComponent().getModel();
            oModel.update(this._sPath, oPayload,
                {
                    success: function (data) {
                        this._fnReset();
                        debugger

                    }.bind(this),
                    error: function (err) {
                        debugger
                    }.bind(this)
                });
        },
        fnUpdateNTable: function () {
            var oViewModel = this.getModel("detailView");
            var that=this;
            var oNTable = this.byId("idNTable");
            var oNItems = oNTable.getItems();
            var sNGroupsComboBoxKey = this.byId("idNGroupsComboBox").getSelectedKey();
            var sNInput = oViewModel.getProperty("/NInput");
            var oNCheckBoxReference = {};
            var oNCheckBox = {};
            var isNSelected = false;
            var oNObject = {};
            var aN = [];
            oNItems.forEach(function (item) {
                if (item.getBindingContext().getObject().N - 1 !== null) {
                    oNCheckBoxReference = $(item.$().find('.sapMCb'))[0];
                    oNCheckBox = sap.ui.getCore().byId(oNCheckBoxReference.getAttribute("id"));
                    isNSelected = oNCheckBox.getProperty("selected");
                    if (!isNSelected) {
                        oNObject = {
                            "N-1": item.getBindingContext().getObject().N - 1,
                            "TEAM": item.getBindingContext().getObject().USER_GROUP,

                        }
                        aN.push(oNObject);
                    }
                }
            })


            oNObject = {};
            if (sNGroupsComboBoxKey !== null) {

                oNObject = {
                    "N-1": sNInput,
                    "TEAM": sNGroupsComboBoxKey,
                }
                const index_N = aN.findIndex(object => object.TEAM === sNGroupsComboBoxKey);
                if (index_N === -1) {
                    aN.push(oNObject);
                }

            }

            //Prep header-level group/changeset params
            var changeSetId = "table";
            var mParameters = {
                "groupId": changeSetId,
                "success": fnsuccess,
                "error": fnerror

            };
            function fnsuccess(data) {

                MessageBox.success("N-1 Success");

            }
            function fnerror(err) {

            }
            this.getOwnerComponent().getModel().setUseBatch(true); //if this is not already done
            var aNPayload = [];
            var oNPayload = {};
            aN.forEach(function (item) {

                oNPayload =
                {
                    "N-1": item.N - 1,
                    "TEAM": item.USER_GROUP,
                };
                aNPayload.push(oNPayload);
                //Then execute the v2 model's Update function
                that.getOwnerComponent().getModel().create("/USER_RIGHT_N_1", oPayload, {
                    "groupId": changeSetId
                });
            });
            //Finally, submit all the batch changes
            that.getOwnerComponent().getModel().submitChanges(mParameters);

        },
        fnUpdateLETable: function () {
            var oViewModel = this.getModel("detailView");
            var that=this;
            var oLETable = this.byId("idLETable");
            var oLEItems = oLETable.getItems();
            var sLEGroupsComboBoxKey = this.byId("idLEGroupsComboBox").getSelectedKey();
            var sLEInput = oViewModel.getProperty("/LEInput");

            var oLECheckBoxReference = {};
            var oLECheckBox = {};
            var isLESelected = false;
            var oLEObject = {};
            var aLE = [];
            oLEItems.forEach(function (item) {
                if (item.getBindingContext().getObject().LEGAL_ENTITY !== null) {
                    oLECheckBoxReference = $(item.$().find('.sapMCb'))[0];
                    oLECheckBox = sap.ui.getCore().byId(oLECheckBoxReference.getAttribute("id"));
                    isLESelected = oLECheckBox.getProperty("selected");
                    if (!isLESelected) {
                        oLEObject = {
                            "LEGAL_ENTITY": item.getBindingContext().getObject().LEGAL_ENTITY,
                            "TEAM": item.getBindingContext().getObject().USER_GROUP,

                        }
                        aLE.push(oLEObject);
                    }
                }
            })

            oLEObject = {};
            if (sLEGroupsComboBoxKey !== null) {

                oLEObject = {
                    "LEGAL_ENTITY": sLEInput,
                    "TEAM": sLEGroupsComboBoxKey,
                }
                const index_LE = aLE.findIndex(object => object.TEAM === sLEGroupsComboBoxKey);
                if (index_LE === -1) {
                    aLE.push(oLEObject);
                }

            }


        },
        fnUpdatePATable: function () {
            var oViewModel = this.getModel("detailView");
            var that=this;
            var oPATable = this.byId("idPATable");
            var oPAItems = oPATable.getItems();
            var sPAGroupsComboBoxKey = this.byId("idPAGroupsComboBox").getSelectedKey();
            var sPAInput = oViewModel.getProperty("/PAInput");

            var oPACheckBoxReference = {};
            var oPACheckBox = {};
            var isPASelected = false;
            var oPAObject = {};
            var aPA = [];
            oPAItems.forEach(function (item) {
                if (item.getBindingContext().getObject().PRODUCT_AREA !== null) {
                    oPACheckBoxReference = $(item.$().find('.sapMCb'))[0];
                    oPACheckBox = sap.ui.getCore().byId(oPACheckBoxReference.getAttribute("id"));
                    isPASelected = oPACheckBox.getProperty("selected");
                    if (!isPASelected) {
                        oPAObject = {
                            "PRODUCT_AREA": item.getBindingContext().getObject().PRODUCT_AREA,
                            "TEAM": item.getBindingContext().getObject().USER_GROUP,

                        }
                        aPA.push(oPAObject);
                    }
                }
            })

            oPAObject = {};
            if (sPAGroupsComboBoxKey !== null) {

                oPAObject = {
                    "PRODUCT_AREA": sPAInput,
                    "TEAM": sPAGroupsComboBoxKey,
                }
                const index_PA = aPA.findIndex(object => object.TEAM === sPAGroupsComboBoxKey);
                if (index_PA === -1) {
                    aPA.push(oPAObject);
                }

            }
        },
        _fnReset: function () {
            var that = this;
            MessageBox.success("User details updated successfully.", {
                actions: [MessageBox.Action.OK],
                onClose: function (sAction) {
                    that.navBackToDetailsScreen()
                }
            });
            var oGroupsMultiComboBox = this.byId("idGroupsMultiComboBox");
            oGroupsMultiComboBox.removeAllSelectedItems();

            var oCheckBoxReference, oCheckBox, isSelected;
            var oTeamsTable = this.byId("editLineItemsList");
            var oItems = oTeamsTable.getItems();
            oItems.forEach(function (item) {
                oCheckBoxReference = $(item.$().find('.sapMCb'))[0];
                oCheckBox = sap.ui.getCore().byId(oCheckBoxReference.getAttribute("id"));
                isSelected = oCheckBox.getProperty("selected");
                if (isSelected) {
                    oCheckBox.setProperty("selected", false);
                }

            })

        },
        onNavBackToDetails:function()
        {
            this.navBackToDetailsScreen();
        }
    });
     });
 